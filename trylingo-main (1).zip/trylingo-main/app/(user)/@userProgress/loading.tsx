// ISSUE: https://github.com/vercel/next.js/issues/65533
// Not working
export default function Loading() {
  return null
}
