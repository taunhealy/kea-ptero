export default function Quests() {
  return <div className="">QUESTS</div>
}
