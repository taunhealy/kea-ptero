export default function Leaderboard() {
  return <div className="">LEADERBOARD</div>
}
