export default function Shop() {
  return <div className="">SHOP</div>
}
