import { UserProgress } from '@/components/user/UserProgress'

export default function Page() {
  return <UserProgress />
}
