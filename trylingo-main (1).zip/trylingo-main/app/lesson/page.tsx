export default async function Lesson() {
  return <div>LESSON PAGE</div>
}
