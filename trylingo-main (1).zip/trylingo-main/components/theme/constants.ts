export const THEME_LIGHT = 'light'
export const THEME_DARK = 'dark'
